package steprunner;

import java.io.IOException;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import reportingClass.JvmReport;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty", "json:src/test/resources/Report/cucumber.json"},
features ="src/test/resources", glue="stepDef",
dryRun=false, monochrome=true)
public class RunnerClass {
	@org.junit.AfterClass
	public static void AfterClass() throws IOException {
		JvmReport.generateJvm("/Users/PRITHIVIRAJ/eclipse-workspace4/Inscale/src/test/resources/Report/cucumber.json");
	}
}
