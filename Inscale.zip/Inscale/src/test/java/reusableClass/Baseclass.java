package reusableClass;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.lang.model.element.Element;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Baseclass {

	public static WebDriver driver;
	
	public static void getDriver(String browserName) {
		switch (browserName) {
		case "Chrome":
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			break;
		
		case "IE":
			WebDriverManager.iedriver().setup();
			driver=new InternetExplorerDriver();
			break;
			
		case "FireFox":
			WebDriverManager.firefoxdriver().setup();
			driver=new FirefoxDriver();
			break;
		case "Edge":
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
			break;
		default:
			break;
		}
	}
	public static String getPropertyValue(String key) throws IOException {
		Properties properties=new Properties();
		
		FileInputStream stream=new FileInputStream("C:\\Users\\PRITHIVIRAJ\\eclipse-workspace4\\Inscale\\src\\test\\resources\\config.properties");
		
		properties.load(stream);
		
		String value=(String)properties.get(key);
		
		return value;
	}

	public static void getUrl(String url) {
		driver.get(url);	
	}
	public static void manageWindow() {
		driver.manage().window().maximize();
	}
	public String getTitle() {
		String title = driver.getTitle();
		return title;
	}
	public String currentUrl() {
		String currentUrl = driver.getCurrentUrl();
		return currentUrl;
	}
	public String getText(WebElement element) {
		String text = element.getText();
		return text;
	}
	public void click(WebElement element) {
		element.click();
	}
	public void clear(WebElement element) {
		element.clear();
	}
	public WebElement findElementById(String attributeValue) {
		WebElement element = driver.findElement(By.id(attributeValue));
		return element;
	}
	public WebElement findElementByName(String attributeValue) {
		WebElement element = driver.findElement(By.id(attributeValue));
		return element;
	}
	public WebElement findElementByClassName(String attributeValue) {
		WebElement element = driver.findElement(By.className(attributeValue));
		return element;
	}
	public String getAttribute(WebElement element) {
		String attribute = element.getAttribute("value");
		return attribute;
	}
	public void sendKeys(WebElement element,String text) {
		element.sendKeys(text);	
	}
	public void keyEnter(WebElement element) {
		element.sendKeys(Keys.ENTER);
	}
	//Waits
	public void implicitWait() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	//Alerts
	public void acceptAlert() {
		Alert al = driver.switchTo().alert();
		al.accept();
	}
	public void dismissAlert() {
		Alert al=driver.switchTo().alert();
		al.dismiss();	
	}
	//Prompt Alert
	public void sendKeyToAlert(String text) {
		Alert alert = driver.switchTo().alert();
		alert.sendKeys(text);
	}
	public void type(WebElement element, String data) {
		element.sendKeys(data);
	}
	
	public void selectOptionByText(WebElement element,String text) {
		Select select=new Select(element);
		select.selectByVisibleText(text);
	}
	public void selectOptionByIndex(WebElement element,int index) {
		Select select=new Select(element);
		select.selectByIndex(index);
	}
	public void enteredUrl(String Url) {
		driver.get(Url);
	}
	public void maximizeWindow() {
		driver.manage().window().maximize();
	}
	public WebElement findElementbyId(String attributeValue) {
		WebElement element=driver.findElement(By.id(attributeValue));
		return element;
	}

	public WebElement dropdownSelection(String attributeValue,int index) {
		WebElement element=driver.findElement(By.name(attributeValue));
		Select select=new Select(element);
		select.selectByIndex(index);
		
		return element;
	}
	public WebElement sendKeysBytext(String attributeValue, String text) {
		WebElement element=driver.findElement(By.name(attributeValue));
		element.sendKeys(text);	
		
		return element;
	}
	public WebElement findElementByXpath(String tagName,String attributeName,String attributeValue) {
		WebElement element = driver.findElement
				(By.xpath("//"+tagName+"[@"+attributeName+"='"+attributeValue+"']"));
		return element;		
	}
	public void clickOption(WebElement element) {
		element.click();	
	}
	public void waits() throws InterruptedException {
		Thread.sleep(5000);
	}
    public void quitBrowser() {
    	driver.quit();
    }
    public void closeBrowser() {
    	driver.close();
    }

}
