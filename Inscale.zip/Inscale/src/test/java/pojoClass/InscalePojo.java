package pojoClass;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import reusableClass.Baseclass;

public class InscalePojo extends Baseclass {
	
	public InscalePojo() {
		PageFactory.initElements(driver,this);
		
	}
	
	@FindBy(xpath ="//button[text()='Bank Manager Login']")
	private WebElement bankManagerLoginCta;

	@FindBy(xpath ="//button[@class='btn btn-lg tab']")
	private WebElement addCustomerCta;
		
	@FindBy(xpath ="(//input[@class='form-control ng-pristine ng-invalid ng-invalid-required ng-touched'])[1]")
	private WebElement firstName;
	
	@FindBy(xpath ="(//input[@class='form-control ng-pristine ng-invalid ng-invalid-required ng-touched'])[2]")
	private WebElement lastName;
	
	@FindBy(xpath ="(//input[@class='form-control ng-pristine ng-invalid ng-invalid-required ng-touched'])[3]")
	private WebElement postCode;
	
	@FindBy(xpath="//button[text()='Add Customer']")
	private WebElement addCustomer;
	
	@FindBy(xpath="//button[@class='btn home']")
	private WebElement homeCta;
	
	@FindBy(xpath="	//button[@class='btn btn-lg tab btn-primary']")
	private WebElement customersCta;
	
	@FindBy(xpath="//input[@class='form-control ng-pristine ng-valid ng-touched']")
	private WebElement searchCustomers;
	
	@FindBy(xpath="(//button[text()='Delete'])[1]")
	private WebElement deleteCta;
	

	public WebElement getDeleteCta() {
		return deleteCta;
	}

	public WebElement getBankManagerLoginCta() {
		return bankManagerLoginCta;
	}

	public WebElement getSearchCustomers() {
		return searchCustomers;
	}

	public WebElement getCustomersCta() {
		return customersCta;
	}
	
	public WebElement getHomeCta() {
		return homeCta;
	}

	

	public WebElement getAddCustomerCta() {
		return addCustomerCta;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public WebElement getPostCode() {
		return postCode;
	}
	public WebElement getAddCustomer() {
		return addCustomer;
	}



}
