package pojoClass;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import reusableClass.Baseclass;

public class AssertionPojo extends Baseclass {
	
	public AssertionPojo() {
		PageFactory.initElements(driver,this);
		
	}
	@FindBy(xpath ="//td[text()='Connely']")
	private WebElement hendryDetails;
	
	@FindBy(xpath="//strong[text()='XYZ Bank']")
	private WebElement xyzText;
	
	public WebElement getHendryDetails() {
		return hendryDetails;
	}
	public WebElement getXyzText() {
		return xyzText;
	}


}
