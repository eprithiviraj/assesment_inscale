package reportingClass;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import reusableClass.Baseclass;

public class JvmReport extends Baseclass {
	
	public static void generateJvm(String jsonFile) throws IOException {
		
		String path = System.getProperty("user.dir");
		
		File file = new File(path + getPropertyValue("jvmReportPath"));
		Configuration config = new Configuration(file, "Inscale");
		
		config.addClassifications("os", "Windows 11");
		config.addClassifications("Browser", "Firefox");
		config.addClassifications("version", "101");
	
		List<String> jsonFiles = new ArrayList<String>();
		jsonFiles.add(jsonFile);
		
		ReportBuilder builder = new ReportBuilder(jsonFiles, config);
		builder.generateReports();
	}
}
