package stepDef;

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import pojoClass.AssertionPojo;
import pojoClass.InscalePojo;
import reusableClass.Baseclass;

public class StepDefinition extends Baseclass {

	public static InscalePojo elements;
	public static AssertionPojo userDetails;
	
	@Given("User is on bank Home page")
	public void user_is_on_bank_home_page() throws IOException {
		getDriver("FireFox");
		
		getUrl("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");

		implicitWait();	
	}
	@When("User selects Bank Manager login and navigate to respective page")
	public void user_selects_bank_manager_login_and_navigate_to_respective_page() {
		String xyzText = getText(userDetails.getXyzText());
		Assert.assertEquals("Verify header text", "XYZ Bank", xyzText);
		click(elements.getBankManagerLoginCta());
	}
	@When("User selects add customer option and navigates to customer form")
	public void user_selects_add_customer_option_and_navigates_to_customer_form() {
		click(elements.getAddCustomerCta());
	  
	}
	@When("User should fills {string} {string} {string}")
	public void user_should_fills(String string, String string2, String string3) {
	   sendKeys(elements.getFirstName(), string);
	   sendKeys(elements.getLastName(), string2);
	   sendKeys(elements.getPostCode(), string3);
	   click(elements.getAddCustomer());
	}
	@Then("User should verify the added customer details")
	public void user_should_verify_the_added_customer_details() {
		click(elements.getHomeCta());
		click(elements.getCustomersCta());
		sendKeys(elements.getSearchCustomers(), "Connely");
		keyEnter(elements.getSearchCustomers());
		
		String hendryDetail = getText(userDetails.getHendryDetails());
		Assert.assertEquals("Verify customer", "Connely", hendryDetail);
	}



	@Given("User is on inscale bank Home page")
	public void user_is_on_inscale_bank_home_page() {
		getDriver("FireFox");
		getUrl("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
	}
	@When("User selects Bank Manager login and navigate to customer page")
	public void user_selects_bank_manager_login_and_navigate_to_customer_page() {
		click(elements.getCustomersCta());
	   
	}
	@When("User selects customers option and navigates to customer details page")
	public void user_selects_customers_option_and_navigates_to_customer_details_page() {
		String xyzText = getText(userDetails.getXyzText());
		Assert.assertEquals("Verify header text", "XYZ Bank", xyzText);
	}
	@Then("User should deletes customer and verify the deleted customer details")
	public void user_should_deletes_customer_details() {
		sendKeys(elements.getSearchCustomers(), "Jackson");
		
	}







}
